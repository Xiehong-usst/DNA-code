function idx640 = loadDataAndProcess3(filename)
    load(filename);
end
