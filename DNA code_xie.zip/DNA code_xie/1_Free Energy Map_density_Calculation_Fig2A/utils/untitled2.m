function [outputArg1,outputArg2] = untitled2(inputArg1,inputArg2)

outputArg1 = inputArg1;
outputArg2 = inputArg2;
end

