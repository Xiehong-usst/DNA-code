% 读取多页16位TIFF堆栈（支持多选）
% [filenames, pathname] = uigetfile('*.tif', '选择多页TIFF文件', 'MultiSelect', 'on');
% if isequal(filenames, 0)
%     disp('用户取消选择');
%     return;
% end
% 
% % 如果只选一个文件，转换为cell数组保持一致性
% if ischar(filenames)
%     filenames = {filenames};
% end
pathname = '.\';
filepath = fullfile(pathname, filename);
info = imfinfo(filepath);
numPages = numel(info);
[~, matFilename, ~] = fileparts(filename);

% 预分配空间（使用cell数组存储每层数据）
allData = cell(numPages, 1);
% 对每个文件进行处理
for z = 1:numPages
        tifImage = imread(filepath, z);
        [height, width] = size(tifImage);
        [X, Y] = meshgrid(1:width, 1:height);
                
        % 获取当前层的所有点数据
        currentData = [X(:), Y(:), repmat(z, numel(X), 1), double(tifImage(:))];
                
         % 仅保留Count ≥ 1的点
        validIdx = currentData(:,4) >= 1;
        allData{z} = currentData(validIdx, :);
end
    
    % 合并所有数据
data = vertcat(allData{:});
data(:,2) = max(data(:,2)) + 1 - data(:,2); % 反转Y轴（匹配ImageJ坐标系）
    
    % 按Count值扩展数据行
repeat_counts = data(:, 4);
new_total_rows = sum(repeat_counts);
expanded_data = zeros(new_total_rows, 3); % 只保留XYZ，不重复Count列
    
current_index = 1;
for i = 1:size(data, 1)
     reps = repeat_counts(i);
     expanded_data(current_index:current_index+reps-1, :) = repmat(data(i, 1:3), reps, 1);
     current_index = current_index + reps;
end
    
    % 创建两个变量：area1_loc_ori和data
area10_loc_ori = expanded_data; % 第一个变量名
data = expanded_data;          % 第二个变量名（相同内容）
    
    % 保存到MAT文件（同时保存两个变量）
save(fullfile(pathname, ['3d_cluster_' matFilename '.mat']), 'area10_loc_ori', 'data');
    % 显示处理信息
disp(['已处理并保存: ' matFilename '.mat']);
disp(['  变量 area10_loc_ori: ' num2str(size(area10_loc_ori, 1)) ' 个点']);
disp(['  变量 data: ' num2str(size(data, 1)) ' 个点']);
disp(' ');
disp('所有文件处理完成！');