function visualizeCylinderWithPoints(points, R, A, B)
    % 三维可视化
    %
    % 输入:
    % points - Nx3的矩阵，代表N个三维空间中的点
    % R - 标量，代表圆柱的半径
    % A, B - 1x3的向量，代表拟合的圆柱轴的两个点

    % 绘制散点数据
    scatter3(points(:,1), points(:,2), points(:,3), 'filled');
    hold on;

    % 计算圆柱的向量
    direction = B - A;
    length_cylinder = norm(direction);
    direction = direction / length_cylinder;

    % 计算圆柱表面的点
    [Xcyl, Ycyl, Zcyl] = cylinder(R);
    Zcyl(1, :) = 0; 
    Zcyl(2, :) = length_cylinder;

    % 将圆柱旋转和平移到合适的位置
    h = surf(Xcyl, Ycyl, Zcyl);
    rotate(h, [0 0 1], rad2deg(acos(dot([0 0 1], direction))));
    center = A + 0.5*(B - A);
    h.XData = h.XData + center(1);
    h.YData = h.YData + center(2);
    h.ZData = h.ZData + center(3);

    % 设置圆柱为半透明
    h.FaceAlpha = 0.5;
    h.EdgeColor = 'none';  % 去除边缘线使其更平滑

    % 设置绘图参数
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    grid on;
    title('Data Points and Fitted Cylinder');
    view(3);  % 设置三维视图
    axis equal;  % 使坐标轴等比例
    hold off;
end
