% 读取多页16位TIFF堆栈（支持多选）
[filenames, pathname] = uigetfile('*.tif', '选择多页TIFF文件', 'MultiSelect', 'on');
if isequal(filenames, 0)
    disp('用户取消选择');
    return;
end

% 如果只选一个文件，转换为cell数组保持一致性
if ischar(filenames)
    filenames = {filenames};
end

% 对每个文件进行处理
for fileIdx = 1:length(filenames)
    filename = filenames{fileIdx};
    filepath = fullfile(pathname, filename);
    info = imfinfo(filepath);
    numPages = numel(info);
    
    % 从文件名中去除扩展名 '.tif'
    [~, matFilename, ~] = fileparts(filename);
    
    % 预分配空间（使用cell数组存储每层数据）
    allData = cell(numPages, 1);
    
    for z = 1:numPages
        tifImage = imread(filepath, z);
        [height, width] = size(tifImage);
        [X, Y] = meshgrid(1:width, 1:height);
        
        % 获取当前层的所有点数据
        currentData = [X(:), Y(:), repmat(z, numel(X), 1), double(tifImage(:))];
        
        % 仅保留Count ≥ 1的点
        validIdx = currentData(:,4) >= 1;
        allData{z} = currentData(validIdx, :);
    end
    
    % 合并所有数据
    data = vertcat(allData{:});
    
    % 反转Y轴（匹配ImageJ坐标系）
    maxY = max(data(:,2));
    data(:,2) = maxY + 1 - data(:,2);
    
    % 直接提取每个位置的唯一坐标点（忽略Count值）
    % 创建只包含XYZ位置的数据矩阵
    positions = data(:, 1:3);
    
    % 使用unique函数获取唯一位置（去除坐标完全相同的重复点）
    uniquePositions = unique(positions, 'rows');
    
    % 将最终数据重命名为data（仅包含唯一位置）
    data = uniquePositions; % 最终输出仅包含唯一XYZ坐标（不含重复点）
    
    % 保存到MAT文件
    save(fullfile(pathname, ['3d_cluster_' matFilename '.mat']), 'data');
    disp(['已处理并保存: ' matFilename '.mat']);
    disp(['原始点数: ' num2str(size(positions, 1)) ' | 去重后点数: ' num2str(size(data, 1))]);
end

disp('所有文件处理完成！');