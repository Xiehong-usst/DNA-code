clear all; close all;
load('3d_cluster_area1_loc.mat'); 
data=area1_loc_ori;
data_ori = data;
epsilon =5;
minPts = 20;
[idx, C] = dbscan(data_ori, epsilon, minPts);
% 绘制3D点云,将不同聚团用不同颜色表示
% 计算聚类的数量
num_clusters = max(idx);
%除去散点
outters=find(idx==-1)
data(outters,:)=[];
idx_ori=idx;
idx(outters,:)=[];
area1_loc = data;  % 去除噪声点后的数据
idx640 = idx;  % 去除噪声点后的聚类标签
%all_labels = idx_ori; 
save('3d_cluster_area1_loc.mat', 'area1_loc', 'idx640', '-append');
disp('已保存处理后的数据到 3d_cluster_area1_loc.mat');
% 生成随机颜色
%colors = rand(num_clusters, 3);
% 根据聚类索引获取颜色
%figure;
%scatter_colors = colors(idx, :);
%scatter3(data_ori(:,1)*3, data_ori(:,2)*3, data_ori(:,3)*3, 10, 'filled','black');    %单色
%hold on
%scatter3(data(:,1)*3, data(:,2)*3, data(:,3)*3, 10, scatter_colors, 'filled');
% 在图形左上角显示参数
%text(0.02, 0.98, 0.98, sprintf('\\epsilon = %d\nminPts = %d', epsilon, minPts), ...
    %'Units', 'normalized', ...
    %'VerticalAlignment', 'top', ...
    %'HorizontalAlignment', 'left', ...
    %'FontSize', 11, ...
    %'BackgroundColor', 'white', ...
    %'EdgeColor', 'black');
%axis equal

%figure;
%scatter3(data(:,1)*3, data(:,2)*3, data(:,3)*3, 10, scatter_colors, 'filled');
% 在图形左上角显示参数
%text(0.02, 0.98, 0.98, sprintf('\\epsilon = %d\nminPts = %d', epsilon, minPts), ...
    %'Units', 'normalized', ...
    %'VerticalAlignment', 'top', ...
    %'HorizontalAlignment', 'left', ...
    %'FontSize', 11, ...
    %'BackgroundColor', 'white', ...
    %'EdgeColor', 'black');
%axis equal

% 加上彩色注释条



