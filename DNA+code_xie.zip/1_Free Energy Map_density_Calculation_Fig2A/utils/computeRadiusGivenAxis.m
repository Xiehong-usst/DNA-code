function [bestRadius, error] = computeRadiusGivenAxis(points, A, B)
    % 输入:
    % points - Nx3的矩阵，代表N个三维空间中的点
    % A, B - 1x3的向量，代表中心轴上的两个点
    %
    % 输出:
    % bestRadius - 标量，代表可以囊括所有点到中心轴距离的90%的长度
    % error - 标量，代表所有点到中心轴距离的平方和

    % 初始化一个向量来存储每个点到中心轴的距离
    distances = zeros(size(points, 1), 1);

    % 计算P - A
    dPA = bsxfun(@minus, points, A);
    
    % 计算B - A的向量和它的范数
    vecBA = B - A;
    normBA = norm(vecBA);
    
    % 计算P - A和B - A的叉积，并求其范数
    crossProduct = cross(dPA, repmat(vecBA, size(points, 1), 1), 2);
    distances = sqrt(sum(crossProduct.^2, 2)) / normBA;
    
    % 计算所有距离的平方和作为error
    error = sum(distances.^2);

    % 为了找到囊括90%点到中心轴距离的长度，首先对距离进行排序
    sortedDistances = sort(distances, 'ascend');
    
    % 计算90%的数量
    numPoints = round(0.9 * size(points, 1));
    
    % 获取可以囊括90%的距离作为bestRadius
    bestRadius = sortedDistances(numPoints);
end
