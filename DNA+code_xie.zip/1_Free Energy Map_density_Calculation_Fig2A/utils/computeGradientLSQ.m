function [a, b, c, d] = computeGradientLSQ(coords, values)
    % 输入:
    % coords - n x 3矩阵，每行是一个点的[x,y,z]坐标
    % values - n x 1向量，每个元素是对应点的标量值
    %
    % 输出:
    % a, b, c - 对应梯度的三个分量
    % d - 截距

    % 获取点的数量
    n = size(coords, 1);

    % 设置A矩阵
    A = [coords, ones(n, 1)]; % [x y z 1]

    % 解最小二乘问题
    params = A \ values; % 使用MATLAB的左除运算来求解线性最小二乘问题

    % 提取参数值
    a = params(1);
    b = params(2);
    c = params(3);
    d = params(4);
end
