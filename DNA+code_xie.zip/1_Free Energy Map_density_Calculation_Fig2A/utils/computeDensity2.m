function density_values = computeDensity2(data_points, radius)
    % 输入:
    % data_points: n x 3 的矩阵, 其中n是点的数量, 每一行表示一个三维空间中的点的坐标
    % radius: 要计算密度的球体的半径
    % 输出:
    % density_values: n x 1 的矩阵, 每个元素表示相应点的密度值

    % 计算球体的体积
    volume = (4/3) * pi * radius^3;
    
    % 获取点的数量
    n = size(data_points, 1);
    
    % 初始化输出数组
    density_values = zeros(n, 1);

    for i = 1:n
        % 对于每一个点, 计算它与其他所有点的距离
        distances = sqrt(sum((data_points - data_points(i,:)).^2, 2));
        
        % 统计距离小于等于radius的点的数量（减1是为了排除点自身）
        count = sum(distances <= radius) - 1;
        
        % 计算并存储密度值
        density_values(i) = count / volume;
    end
end
