function [bestA, bestB, bestRadius, minError] = findPartBestAxis(points, X1, Y1, Z1, X2, Y2, Z2)
    % 根据误差找到最佳的AB点
    %
    % 输入:
    % points - Nx3的矩阵，代表N个三维空间中的点
    % X, Y, Z - 对应的球面上的点的坐标矩阵
    %
    % 输出:
    % bestA, bestB - 1x3的向量，代表最佳的AB点
    % bestRadius - 标量，代表对应的最佳半径
    % minError - 标量，代表对应的最小误差

    minError = Inf;  % 初始化为无穷大，以便于比较
    [numRows1, numCols1] = size(X1);
    [numRows2, numCols2] = size(X2);

    for i = 1:(numRows1 * numCols1)
        A = [X1(i), Y1(i), Z1(i)];
        for j = 1:(numRows2 * numCols2)
            B = [X2(j), Y2(j), Z2(j)];
            if sum((A-B).^2) > 10^(-4)  % 确保A和B不是同一点
                
                [radius, error] = computeRadiusGivenAxis(points, A, B);

                % 如果当前误差比之前的小，更新bestA, bestB, bestRadius和minError
                if error < minError
                    bestA = A;
                    bestB = B;
                    bestRadius = radius;
                    minError = error;
                end
            end
        end
    end

    % 以下为新添加的部分
    normalized_AB = (bestB - bestA) / norm(bestB - bestA);  % 归一化的AB向量
    inner_products = zeros(size(points, 1), 1);  % 初始化内积向量

    for k = 1:size(points, 1)
        AC = points(k, :) - bestA;
        inner_products(k) = dot(AC, normalized_AB);
    end
    
    r1 = prctile(inner_products, 2);
    r2 = prctile(inner_products, 98);
    
    newA = bestA + r1 * normalized_AB;  % 更新A点
    newB = bestA + r2 * normalized_AB;  % 更新B点
    bestA = newA;
    bestB = newB;
end
