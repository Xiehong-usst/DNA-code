function data1 = loadDataAndProcess2(filename)
    % 根据'_'将文件名分段
    parts = split(filename, '_');
    
    % 寻找包含"area"前缀的部分
    areaPart = [];
    for i = 1:length(parts)
        if startsWith(parts{i}, 'area')
            areaPart = parts{i};
            break;
        end
    end
    
    if isempty(areaPart)
        error('No areaXX found in the filename!');
    end

    % 提取数字k
    k = regexp(areaPart, '\d+', 'match');
    if isempty(k)
        error('No number found in the areaXX part!');
    end
    k = k{1};

    % 动态地加载文件中的变量
    load(filename);

    % 通过eval函数获取对应的变量名
    variable_name = strcat('area', k, '_loc');
    if ~exist(variable_name, 'var')
        error('Variable %s not found in the file!', variable_name);
    end
    data = eval(variable_name);

    data1 = data * 3;  % 以3倍缩放调整数据
end
