function [pointsAB, pointsCD] = classifyPoints(A, B, C, D, dataPoints)
    % 输入:
    % A, B, C, D - 直线的两个端点
    % dataPoints - Nx3的矩阵，表示散点数据
    %
    % 输出:
    % pointsAB, pointsCD - 分别归类到AB和CD的数据点

    numData = size(dataPoints, 1);
    pointsAB = [];
    pointsCD = [];
    
    for i = 1:numData
        point = dataPoints(i, :);
        
        % 计算点到线AB和线CD的距离
        distToAB = pointToLineDistance(point, A, B);
        distToCD = pointToLineDistance(point, C, D);
        
        % 根据距离进行归类
        if distToAB < distToCD
            pointsAB = [pointsAB; point];
        else
            pointsCD = [pointsCD; point];
        end
    end
end

function d = pointToLineDistance(P, A, B)
    % 计算点P到线段AB的距离
    % 使用向量投影的方法
    AB = B - A;
    AP = P - A;
    proj = dot(AP, AB) / dot(AB, AB);
    
    if proj < 0
        % P在A的外侧
        d = norm(AP);
    elseif proj > 1
        % P在B的外侧
        d = norm(P - B);
    else
        % P在AB线段的延长线上
        projPoint = A + proj * AB;
        d = norm(P - projPoint);
    end
end
