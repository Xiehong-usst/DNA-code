function inside = is_inside_cylinder(points, A, B, R)
    % 输入:
    % points: 点的坐标，每一行是一个3D点，例如 points = [x1 y1 z1; x2 y2 z2; ...]
    % A, B: 圆柱体轴线的两个端点
    % R: 圆柱体的半径
    % 输出:
    % inside: 一个列向量，1表示这个点在圆柱内部，0表示这个点不在圆柱内部

    % 初始化返回向量
    n = size(points, 1);
    inside = zeros(n, 1);

    % 计算向量AB
    AB = B - A;
    AB_length = norm(AB);
    AB_unit = AB / AB_length;  % AB的单位向量

    for i = 1:n
        P = points(i, :);  % 当前点
        AP = P - A;  % 向量AP

        % 计算点P在AB上的投影长度
        proj_length = dot(AP, AB_unit);
        % 计算投影点Q
        Q = A + proj_length * AB_unit;
        PQ_length = norm(P - Q);  % PQ的长度

        % 判断垂足Q是否在线段AB上
        if proj_length >= 0 && proj_length <= AB_length
            if PQ_length < R
                inside(i) = 1;  % 在圆柱内部
            end
        end
    end
end
