function cylinders = recursiveCylinderFitting(dataPoints)
    % 初始化返回列表
    cylinders = {};
    
    % 如果数据点数量太小，直接返回空列表
    if size(dataPoints, 1) < 3
        return;
    end
    
    tic;
    % 对数据点进行单圆柱体拟合
    [bestA, bestB, bestRadius] = computeBestAxisForSet(dataPoints);
    d1 = (sum((bestA - bestB).^2))^(1/2);
    singleCylinderVolume = pi*bestRadius^2*d1;

    % 尝试将数据点拆分为两组并进行双圆柱体拟合
    [O, R_sphere] = enclosingBall(dataPoints);
    numTheta = 20;
    numPhi = 20;
    [bestA1, bestB1, bestA2, bestB2, bestTotalVolume, bestRadius1, bestRadius2, dataPoints1, dataPoints2] = searchABCD(O, R_sphere, numTheta, numPhi, dataPoints);
    toc;

    % 判断拟合效果
    bestTotalVolume = inf;%%%%%%20250726
    if bestTotalVolume < singleCylinderVolume
        % 两个圆柱体的拟合效果更好
        % 递归地处理每个子集
        fprintf('Cut continue...');
        cylinders1 = recursiveCylinderFitting(dataPoints1);
        cylinders2 = recursiveCylinderFitting(dataPoints2);

        % 合并两个子集的结果
        cylinders = [cylinders1, cylinders2];
        
    else
        % 单个圆柱体的拟合效果更好
        cylinder = struct('bestA', bestA, 'bestB', bestB, 'bestRadius', bestRadius, 'dataPoints', dataPoints);
        cylinders = {cylinder};
        fprintf('Stop for one.');
    end
end
