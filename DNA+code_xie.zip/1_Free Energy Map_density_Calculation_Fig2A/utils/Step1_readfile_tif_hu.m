% 读取多页16位TIFF堆栈（支持多选）
% [filenames, pathname] = uigetfile('*.tif', '选择多页TIFF文件', 'MultiSelect', 'on');
% if isequal(filenames, 0)
%     disp('用户取消选择');
%     return;
% end
% 
% % 如果只选一个文件，转换为cell数组保持一致性
% if ischar(filenames)
%     filenames = {filenames};
% end
% 对每个文件进行处理
pathname = '.\';
filepath = fullfile(pathname, filename);
info = imfinfo(filepath);
numPages = numel(info);

% 从文件名中去除扩展名 '.tif'
[~, matFilename, ~] = fileparts(filename);

% 预分配空间（使用cell数组存储每层数据）
allData = cell(numPages, 1);

% 对每个文件进行处理
    
for z = 1:numPages
     tifImage = imread(filepath, z);
     [height, width] = size(tifImage);
     [X, Y] = meshgrid(1:width, 1:height);
        
       % 获取当前层的所有点数据
     currentData = [X(:), Y(:), repmat(z, numel(X), 1), double(tifImage(:))];
        
      % 仅保留Count ≥ 1的点
      validIdx = currentData(:,4) >= 1;
      allData{z} = currentData(validIdx, :);
 end
    
  % 合并所有数据
data = vertcat(allData{:});
data(:, [1, 2]) = data(:, [2, 1]);
%data(:,2) = max(data(:,2)) + 1 - data(:,2); % 反转Y轴（匹配ImageJ坐标系）
count=data(:,4);
data(:,4) = [];
shortName = matFilename(end-4:end); % 取后 5 位
% 构造新文件名（例如：'experiment_loc.mat'）
outputFilename = ['3d_cluster_',shortName, '_loc.mat'];
newVarName = [shortName, '_loc_ori']; 
eval([newVarName ' = data;']); 
% 保存到MAT文件（文件名与TIFF文件相同，不含扩展名）
save(fullfile(pathname, outputFilename), newVarName, 'count');

disp('所有文件处理完成！');