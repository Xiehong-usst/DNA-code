function [X,Y,Z,gradient_magnitude] = compute_gradient_magnitude(data, d, h, q)
    %% 使用说明：计算三维标量场的梯度大小
    % data: 输入的三维数据。数据格式：(n, 3)，其中n表示数据点的数量。
    % d: 网格的间隔大小。
    % h: 与compute_density函数相关的参数。
    % q: 用于局部筛选的距离阈值。
    % 
    % 输出：
    % X, Y, Z: 表示三维空间的坐标网格。
    % gradient_magnitude: 每个网格点的梯度大小。
    %
    % 函数内部首先利用compute_density函数计算三维密度场。然后，对于每个网格点，它局部筛选出可能与该点相近的数据点。
    % 对这些局部数据点，它使用computeGradientLSQ函数计算梯度，并存储其大小。
    %
    % 为了提高计算效率，本函数利用并行计算进行处理，并将计算分为多个批处理块。
    %
    % 示例：
    % [X, Y, Z, gradient_magnitude] = compute_gradient_magnitude(data, 0.5, 1, 0.1);    
    
    % 使用第一个函数计算三维标量场
    tic;
    [X_density, Y_density, Z_density, x1_range, y1_range, z1_range, value] = compute_density(data, d, h);
    toc;

    x_min = min(data(:,1))-h;
    x_max = max(data(:,1))+h;
    y_min = min(data(:,2))-h;
    y_max = max(data(:,2))+h;
    z_min = min(data(:,3))-h;
    z_max = max(data(:,3))+h;

    x_range = x_min:d:x_max;
    y_range = y_min:d:y_max;
    z_range = z_min:d:z_max;

    [X, Y, Z] = meshgrid(x_range, y_range, z_range);

    gradient_magnitude = zeros(size(X));
    N = numel(X);
    disp(N);
    tic;
    show_button = 0;
    batch_size = 10000;
    for u = 1:ceil(N/batch_size)
        if mod(u,round(ceil(N/batch_size)/100)) == 0
            fprintf('-');
            if show_button == 0
                toc;
                tic;
                show_button = 1;
            end
        end
        un1 = (u - 1)*batch_size;
        topi = min(N - un1,batch_size);
        sub_gradient_magnitude = zeros(1,topi);
        for i = 1:topi
            % 当前网格点的坐标
            point = [X(i+un1), Y(i+un1), Z(i+un1)];
            
            % 使用坐标范围进行初步筛选
            x_idx = find(x1_range >= point(1) - q & x1_range <= point(1) + q);
            y_idx = find(y1_range >= point(2) - q & y1_range <= point(2) + q);
            z_idx = find(z1_range >= point(3) - q & z1_range <= point(3) + q);


            % 获取对应的X_density, Y_density, Z_density和value的子集
            X_sub = X_density(y_idx,x_idx,z_idx);
            Y_sub = Y_density(y_idx,x_idx,z_idx);
            Z_sub = Z_density(y_idx,x_idx,z_idx);
            value_sub = value(y_idx,x_idx,z_idx);
            
            % 对这个子集计算真正的距离
            distances = sqrt((X_sub - point(1)).^2 + (Y_sub - point(2)).^2 + (Z_sub - point(3)).^2);
            
            % 获取距离小于h1的点和它们的标量值
            mask = distances < q;
            local_coords = [X_sub(mask), Y_sub(mask), Z_sub(mask)];
            local_values = value_sub(mask);

    
            % 使用第二个函数计算梯度
            [a, b, c, ~] = computeGradientLSQ(local_coords, local_values);
    
            % 计算梯度的模长
            sub_gradient_magnitude(i) = sqrt(a^2 + b^2 + c^2);
        end
        gradient_magnitude(un1+1:un1+topi) = sub_gradient_magnitude(1:topi);
    end
    toc;
end
