function [matched_points, matched_ids, transform_info] = find_matching_points(A, B)
% 输入：A (14x3), B (8x3)
% 输出：
%   matched_points: 匹配的8个点在A中的坐标 (8x3)
%   matched_ids: 匹配点在原始A中的行索引 (8x1向量)
%   transform_info: 包含详细变换信息的结构体

% 设置容差
tolerance = 1e-6;

% 1. 预处理B：计算质心、距离并排序
centroid_B = mean(B, 1);
dB = sqrt(sum((B - centroid_B).^2, 2));  % 计算欧氏距离
[dB_sorted, idx_B] = sort(dB);          % 按距离排序
B_sorted = B(idx_B, :);                 % 排序后的点集

% 2. 生成所有可能的正交变换矩阵 (48种)
permutations = perms(1:3);  % 6种坐标置换
signs = [1 1 1; 1 1 -1; 1 -1 1; 1 -1 -1; -1 1 1; -1 1 -1; -1 -1 1; -1 -1 -1]; % 8种符号组合

% 3. 获取所有14选8的组合
combinations = nchoosek(1:size(A,1), 8);

% 4. 遍历所有组合
for c = 1:size(combinations, 1)
    ids = combinations(c, :);  % 保存原始ID
    A8 = A(ids, :);  % 当前候选点集
    
    % 5. 计算A8的质心和距离
    centroid_A8 = mean(A8, 1);
    dA = sqrt(sum((A8 - centroid_A8).^2, 2));  % 点到质心距离
    
    % 6. 比较距离分布 (关键优化步骤)
    [dA_sorted, idxA] = sort(dA);  % 距离排序
    if ~all(abs(dA_sorted - dB_sorted) < tolerance)
        continue;  % 距离序列不匹配，跳过
    end
    
    % 7. 对相同距离的点进行分组处理
    unique_dists = uniquetol(dA_sorted, tolerance);
    same_dist_groups = cell(size(unique_dists));
    
    % 按距离值分组
    for i = 1:numel(unique_dists)
        dist = unique_dists(i);
        mask = abs(dA_sorted - dist) < tolerance;
        same_dist_groups{i} = find(mask);
    end
    
    % 8. 生成点索引的所有可能排列
    all_idx_permutations = {1:8};  % 初始顺序
    for g = 1:numel(same_dist_groups)
        group = same_dist_groups{g};
        if numel(group) > 1
            % 为每组相同距离的点生成所有排列
            new_perms = {};
            for p = 1:numel(all_idx_permutations)
                base = all_idx_permutations{p};
                group_perms = perms(group);
                for r = 1:size(group_perms, 1)
                    temp = base;
                    temp(group) = base(group_perms(r, :));
                    new_perms{end+1} = temp;
                end
            end
            all_idx_permutations = new_perms;
        end
    end
    
    % 9. 尝试所有可能的点顺序
    for order_idx = 1:numel(all_idx_permutations)
        idx_perm = all_idx_permutations{order_idx};
        A8_sorted = A8(idxA(idx_perm), :);  % 按当前顺序排列的点
        
        % 10. 尝试所有正交变换
        for perm_idx = 1:size(permutations, 1)
            for sign_idx = 1:size(signs, 1)
                perm = permutations(perm_idx, :);
                sign_vals = signs(sign_idx, :);
                
                % 构造正交变换矩阵
                R = zeros(3);
                for dim = 1:3
                    R(dim, perm(dim)) = sign_vals(dim);
                end
                
                % 应用变换
                A_transformed = A8_sorted * R;
                
                % 计算平移向量
                centroid_trans = mean(A_transformed, 1);
                T = centroid_B - centroid_trans;
                
                % 应用平移
                A_aligned = A_transformed + T;
                
                % 11. 检查是否匹配
                match = true;
                for i = 1:size(B_sorted, 1)
                    dist = norm(A_aligned(i, :) - B_sorted(i, :));
                    if dist > tolerance
                        match = false;
                        break;
                    end
                end
                
                % 12. 如果匹配，构造变换描述并返回结果
                if match
                    matched_points = A8;
                    matched_ids = ids;  % 返回原始ID
                    
                    % 构建变换描述
                    axis_names = {'X', 'Y', 'Z'};
                    
                    % 坐标置换描述
                    perm_desc = {};
                    for dim = 1:3
                        perm_desc{end+1} = [axis_names{dim} ' → ' axis_names{perm(dim)}];
                    end
                    
                    % 坐标翻转描述
                    flip_desc = {};
                    for dim = 1:3
                        if sign_vals(dim) == -1
                            flip_desc{end+1} = [axis_names{perm(dim)} '轴取反'];
                        end
                    end
                    
                    % 输出变换结果
                    disp('================================================================');
                    disp('成功找到匹配！变换步骤如下：');
                    disp('1. 坐标轴置换：');
                    fprintf('    • %s\n', perm_desc{:});
                    
                    if ~isempty(flip_desc)
                        disp('2. 坐标轴翻转：');
                        fprintf('    • %s\n', flip_desc{:});
                    else
                        disp('2. 坐标轴翻转：无');
                    end
                    
                    disp('3. 平移变换：');
                    fprintf('    • X方向: %.4f\n', T(1));
                    fprintf('    • Y方向: %.4f\n', T(2));
                    fprintf('    • Z方向: %.4f\n', T(3));
                    
                    disp('4. 匹配点ID：');
                    fprintf('    ');
                    for i = 1:8
                        fprintf('%d ', ids(i));  % 显示原始ID
                    end
                    fprintf('\n');
                    
                    disp('================================================================');
                    disp(['完整变换公式：' ...
                        '新坐标 = [原始' axis_names{perm(1)} ', 原始' axis_names{perm(2)} ', 原始' axis_names{perm(3)} ']']);
                    if sign_vals(1) == -1
                        fprintf('                × [-1, ');
                    else
                        fprintf('                × [1, ');
                    end
                    if sign_vals(2) == -1
                        fprintf('-1, ');
                    else
                        fprintf('1, ');
                    end
                    if sign_vals(3) == -1
                        fprintf('-1]');
                    else
                        fprintf('1]');
                    end
                    fprintf(' + [%.4f, %.4f, %.4f]\n', T(1), T(2), T(3));
                    disp('================================================================');
                    
                    % 保存变换信息到结构体
                    transform_info = struct();
                    transform_info.permutation = perm;
                    transform_info.signs = sign_vals;
                    transform_info.translation = T;
                    transform_info.rotation_matrix = R;
                    transform_info.matched_ids = ids;  % 包含在结构体中
                    
                    return;
                end
            end
        end
    end
end

error('未找到匹配的点集。');
end