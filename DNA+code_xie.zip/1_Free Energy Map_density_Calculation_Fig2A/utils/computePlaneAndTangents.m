function [a, b, c, d1, d2] = computePlaneAndTangents(O, pointA, R)

    % 计算OA
    OA = pointA - O;

    % 找一个与OA垂直的向量且在XOY平面上
    V = cross(OA, [0, 0, 1]);

    % 单位化这个向量，并乘以R得到B的坐标
    V_unit = V / norm(V);
    B = O + R * V_unit;
    B(3) = O(3); % 确保B的z坐标与O相同

    % 计算OB
    OB = B - O;

    % 找面OAB的法向量
    N = cross(OA, OB);

    % 单位化法向量
    N_unit = N / norm(N);

    % 面的方程是 ax + by + cz = d
    % 由于O在面上，我们可以得到d为
    d = dot(N_unit, O);
    
    a = N_unit(1);
    b = N_unit(2);
    c = N_unit(3);

    % 对于接触点，它到面的距离就是R
    % 使用点到面的距离公式: |ax1 + by1 + cz1 - d|/sqrt(a^2 + b^2 + c^2) = R
    % 解得d的两个值为
    d1 = d - R * norm(N_unit);
    d2 = d + R * norm(N_unit);

    if d1 > d2
        temp = d1;
        d1 = d2;
        d2 = temp;
    end

end
