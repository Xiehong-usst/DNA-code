function [X_density, Y_density, Z_density, x1_range, y1_range, z1_range, value] = compute_density(data, d, h)
%%
%该函数的主要目的是为了计算给定数据集在特定球体内的密度。
% %函数的输出是七个变量
% 包括三个方向的密度（X_density，Y_density，Z_density）
% 和这三个方向的密度对应的范围（x1_range，y1_range，z1_range）
% 以及最后计算得到的密度值（value）。
% 以下是该函数详细的步骤：

% 函数首先找到数据在三个维度（X，Y，Z）上的最大和最小值
% 并在此基础上加上一个额外的h值，以确定计算密度的球体的边界。

% 利用定义的间隔 d 在这个球体上创建一个三维网格。

% 初始化一个名为value的数组，该数组的大小与网格相同，用于记录每个网格点的计数。

% 对于数据集中的每个数据点，找到该数据点周围球体内的所有网格点。

% 对于这些网格点，检查它们是否真的在数据点周围的 h 球体范围内。
% 如果在范围内，则将对应的value数组的值加1。
% 
% 在遍历完所有数据点后，将每个网格点的计数值除以球的体积（V），得到该方向的密度。
% 计算数据的边界
    x_min = min(data(:,1)) - h;
    x_max = max(data(:,1)) + h;
    y_min = min(data(:,2)) - h;
    y_max = max(data(:,2)) + h;
    z_min = min(data(:,3)) - h;
    z_max = max(data(:,3)) + h;

    % 根据间隔d创建网格
    x1_range = x_min:d:x_max;
    y1_range = y_min:d:y_max;
    z1_range = z_min:d:z_max;

    [X_density, Y_density, Z_density] = meshgrid(x1_range, y1_range, z1_range);

    % 初始化value数组
    value = zeros(size(X_density));

    % 计算球的体积
    V = (4/3) * pi * h^3;

    % 遍历每个数据点
    for i = 1:size(data, 1)
        % 当前数据点的坐标
        point = data(i, :);

        % 确定此数据点周围的球体范围内可能受影响的网格点的索引
        x_idx = find(x1_range >= point(1) - h & x1_range <= point(1) + h);
        y_idx = find(y1_range >= point(2) - h & y1_range <= point(2) + h);
        z_idx = find(z1_range >= point(3) - h & z1_range <= point(3) + h);

        % 对于这些可能的网格点，检查它们是否真的在数据点周围的球体范围内
        for xx = x_idx
            for yy = y_idx
                for zz = z_idx
                    if norm([X_density(yy, xx, zz), Y_density(yy, xx, zz), Z_density(yy, xx, zz)] - point) <= h
                        value(yy, xx, zz) = value(yy, xx, zz) + 1;
                    end
                end
            end
        end
    end

    % 最后，将每个网格点的计数除以球的体积来得到密度值
    value = value / V;
end
