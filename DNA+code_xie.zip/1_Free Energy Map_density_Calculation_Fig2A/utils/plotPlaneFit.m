function plotPlaneFit(coords, values, a, b, c, d)
    % 输入:
    % coords - n x 3矩阵，每行是一个点的[x,y,z]坐标
    % values - n x 1向量，每个元素是对应点的标量值
    % a, b, c, d - 拟合平面的参数

    % 计算每个点到平面的垂足
    footCoords = zeros(size(coords));
    for i = 1:size(coords,1)
        % 该公式是由点到平面的距离公式得到的
        t = (a*coords(i,1) + b*coords(i,2) + c*coords(i,3) + d) / (a^2 + b^2 + c^2);
        footCoords(i,:) = coords(i,:) - t * [a, b, c];
    end
    footValues = a*footCoords(:,1) + b*footCoords(:,2) + c*footCoords(:,3) + d;

    figure;

    % 在x-y-value空间展示
    subplot(1,3,1);
    hold on;
    for i = 1:size(coords,1)
        plot3([coords(i,1), footCoords(i,1)], [coords(i,2), footCoords(i,2)], [values(i), footValues(i)], 'k-');
    end
    xlabel('X');
    ylabel('Y');
    zlabel('Value');
    title('Projection in X-Y-Value space');
    view(2);
    hold off;

    % 在y-z-value空间展示
    subplot(1,3,2);
    hold on;
    for i = 1:size(coords,1)
        plot3([coords(i,2), footCoords(i,2)], [coords(i,3), footCoords(i,3)], [values(i), footValues(i)], 'k-');
    end
    xlabel('Y');
    ylabel('Z');
    zlabel('Value');
    title('Projection in Y-Z-Value space');
    view(2);
    hold off;

    % 在x-z-value空间展示
    subplot(1,3,3);
    hold on;
    for i = 1:size(coords,1)
        plot3([coords(i,1), footCoords(i,1)], [coords(i,3), footCoords(i,3)], [values(i), footValues(i)], 'k-');
    end
    xlabel('X');
    ylabel('Z');
    zlabel('Value');
    title('Projection in X-Z-Value space');
    view(2);
    hold off;
end
