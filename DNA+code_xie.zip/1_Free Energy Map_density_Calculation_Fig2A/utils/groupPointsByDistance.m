function groupedPoints = groupPointsByDistance(P, A, B, d)
% 初始化一个空的cell数组来存储分组
groupedPoints = {};

% 计算向量AB和它的单位向量
AB = B - A;
AB_length = norm(AB);
AB_unit = AB / AB_length;

% 对每个点P进行处理
for i = 1:size(P, 1)
% 计算向量AP
AP = P(i, :) - A;

% 计算点P在AB上的投影长度
proj_length = dot(AP, AB_unit);

% 确定投影点Q到A的距离属于哪个区间
distance = proj_length;
groupIndex = ceil(distance / d);

% 如果该组尚未创建，则创建它
if groupIndex > length(groupedPoints) || isempty(groupedPoints{groupIndex})
groupedPoints{groupIndex} = [];
end

% 将点P添加到对应的组中
groupedPoints{groupIndex} = [groupedPoints{groupIndex}; P(i, :)];
end
end
