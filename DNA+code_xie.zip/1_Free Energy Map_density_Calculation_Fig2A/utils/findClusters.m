function clusters = findClusters(data)
    % 使用MATLAB的dbscan函数
    % 设置距离阈值为5，并设置最小点数为1（只要距离<5都认为是同一个聚团）
    clusterIndices = dbscan(data, 5, 1);

    % 根据dbscan的输出构建聚团
    uniqueClusters = unique(clusterIndices);
    % 删除-1，因为dbscan会用-1标记噪音点
    uniqueClusters(uniqueClusters == -1) = [];
    
    clusters = cell(length(uniqueClusters), 1);
    for k = 1:length(uniqueClusters)
        clusters{k} = data(clusterIndices == uniqueClusters(k), :);
    end
end
