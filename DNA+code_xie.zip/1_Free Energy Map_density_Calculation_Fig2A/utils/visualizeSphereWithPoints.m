function visualizeSphereWithPoints(points, O, R_sphere)
    % 三维可视化
    %
    % 输入:
    % points - Nx3的矩阵，代表N个三维空间中的点
    % O - 1x3的向量，代表球的中心
    % R_sphere - 标量，代表球的半径

    % 绘制散点数据
    scatter3(points(:,1), points(:,2), points(:,3), 'filled');
    hold on;

    % 使用sphere函数创建一个单位球
    [Xs, Ys, Zs] = sphere(50); % 50是创建球的分辨率，您可以根据需要修改它

    % 缩放和平移到合适的位置
    h = surf(R_sphere*Xs + O(1), R_sphere*Ys + O(2), R_sphere*Zs + O(3));

    % 设置球体为半透明
    h.FaceAlpha = 0.5;
    h.EdgeColor = 'none';  % 去除边缘线使其更平滑

    % 设置绘图参数
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    grid on;
    title('Data Points and Fitted Bounding Sphere');
    view(3);  % 设置三维视图
    axis equal;  % 使坐标轴等比例
    hold off;
end
