function [X, Y, Z] = generatePartPointsOnSphere(O, R, numTheta, numPhi, ThetaChosen, PhiChosen)
    % 生成球面上的点的坐标
    %
    % 输入:
    % O - 1x3的向量，代表球心坐标
    % R - 标量，代表球的半径
    % numTheta - \theta的采样数量
    % numPhi - \phi的采样数量
    %
    % 输出:
    % X, Y, Z - 对应的球面上的点的坐标矩阵

    % 初始化Theta和Phi
    theta = linspace(ThetaChosen-pi/10, ThetaChosen+pi/10, numTheta);
    phi = linspace(PhiChosen-pi/5, PhiChosen+pi/5, numPhi);

    [Theta, Phi] = meshgrid(theta, phi);

    % 将Theta和Phi转化为坐标
    X = R .* sin(Theta) .* cos(Phi) + O(1);
    Y = R .* sin(Theta) .* sin(Phi) + O(2);
    Z = R .* cos(Theta) + O(3);
end