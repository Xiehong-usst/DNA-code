% computePlaneAndTangents函数和之前一样

% 随机生成球心O和半径R
O = rand(1, 3) * 10;  % 假设在[0, 10]的立方体中随机生成
R = rand() * 5;       % 假设半径随机在[0, 5]之间

% 随机生成点C
C = rand(1, 3) * 10;

% 计算OC向量和单位化
OC = C - O;
OC_unit = OC / norm(OC);

% 在射线OC上找到距离为R的点A
A = O + R * OC_unit;

[a, b, c, d1, d2] = computePlaneAndTangents(O, A, R);

% 计算平均值d
d = (d1 + d2) / 2;

% 可视化
figure;

% 画球的网格线
[x, y, z] = sphere(100);
surf(x * R + O(1), y * R + O(2), z * R + O(3), 'FaceColor', 'none', 'EdgeColor', 'k');
hold on;

% 画平面
[x_plane, y_plane] = meshgrid(O(1) - 2*R : 0.5 : O(1) + 2*R, O(2) - 2*R : 0.5 : O(2) + 2*R);
z_plane = (d - a * x_plane - b * y_plane) / c;
surf(x_plane, y_plane, z_plane, 'FaceColor', 'r', 'EdgeColor', 'none', 'FaceAlpha', 0.7);

% 画点O和A
plot3(O(1), O(2), O(3), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
plot3(A(1), A(2), A(3), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');

% 随机生成球心附近的点
numPoints = 50; % 可根据需要更改
randomPoints = repmat(O, numPoints, 1) + (rand(numPoints, 3) - 0.5) * 2 * R;  % 在球心的2R范围内生成点

% 检查点是否满足条件 ax + by + cz > (d1 + d2) / 2
condition = a * randomPoints(:, 1) + b * randomPoints(:, 2) + c * randomPoints(:, 3) > d;

% 画满足条件的红点和不满足条件的蓝点
plot3(randomPoints(condition, 1), randomPoints(condition, 2), randomPoints(condition, 3), 'ro', 'MarkerSize', 6);
plot3(randomPoints(~condition, 1), randomPoints(~condition, 2), randomPoints(~condition, 3), 'bo', 'MarkerSize', 6);

xlabel('x');
ylabel('y');
zlabel('z');
axis equal;
view(3);
title('Visualization of O, A, Sphere, Plane, and Random Points');
hold off;
