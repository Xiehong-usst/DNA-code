function [bestA, bestB, bestC, bestD, bestTotalVolume, bestRadiusAB, bestRadiusCD, bestpointsAB, bestpointsCD] = searchABCD(O, R, numTheta, numPhi, dataPoints)
    % 初始化最佳体积为正无穷，以便在后面的计算中找到更小的值
    bestTotalVolume = Inf;

    % 使用generatePointsOnSphere函数在球面上均匀生成点
    [X, Y, Z] = generatePointsOnSphere(O, R, numTheta, numPhi);
    numd = 10;
    
    % 创建临时存储变量来保存每个迭代的结果
    numPoints = numel(X);
    tempTotalVolume = Inf * ones(numPoints, 1);
    tempA = zeros(numPoints, 3);
    tempB = zeros(numPoints, 3);
    tempC = zeros(numPoints, 3);
    tempD = zeros(numPoints, 3);
    tempRadiusAB = zeros(numPoints, 1);
    tempRadiusCD = zeros(numPoints, 1);
    tempPointsAB = cell(numPoints, 1);
    tempPointsCD = cell(numPoints, 1);
    
    % 使用parfor进行并行计算
    parfor idxA = 1:numPoints
        pointA = [X(idxA) Y(idxA) Z(idxA)];
        
        % 计算与当前点相关的平面和切线
        [a, b, c, d1, d2] = computePlaneAndTangents(O, pointA, R);
        
        % 计算数据点与当前平面的距离
        u1 = dataPoints*[a b c]';
        
        % 线性插值计算距离
        d = linspace(d1, d2, numd);
        
        % 初始化局部最佳体积为正无穷
        localBestVolume = Inf;

        % 循环处理每个距离值
        for k = 1:numel(d)
            n1 = find(u1 > d(k));
            n2 = find(u1 <= d(k));
            pointsAB = dataPoints(n1,:);
            pointsCD = dataPoints(n2,:);

            % 如果点的数量小于3，则跳过此迭代
            if min(numel(pointsAB),numel(pointsCD)) < 3
                continue;
            end

            % 计算pointsAB和pointsCD的最佳轴和半径
            [bestA_AB, bestB_AB, bestRadius_AB] = computeBestAxisForSet(pointsAB);
            [bestA_CD, bestB_CD, bestRadius_CD] = computeBestAxisForSet(pointsCD);

            % 如果计算出的半径小于10，则设置为10
            if bestRadius_AB < 15% 15
                bestRadius_AB = 15;
            end
            if bestRadius_CD < 15
                bestRadius_CD = 15;
            end

            % 计算两个圆柱的总体积
            volume_AB = computeCylinderVolume(bestA_AB, bestB_AB, bestRadius_AB);
            volume_CD = computeCylinderVolume(bestA_CD, bestB_CD, bestRadius_CD);
            totalVolume = volume_AB + volume_CD;

            % 如果当前体积比局部最佳体积小，则更新局部最佳值
            if totalVolume < localBestVolume
                localBestVolume = totalVolume;
                tempA(idxA,:) = bestA_AB;
                tempB(idxA,:) = bestB_AB;
                tempC(idxA,:) = bestA_CD;
                tempD(idxA,:) = bestB_CD;
                tempRadiusAB(idxA) = bestRadius_AB;
                tempRadiusCD(idxA) = bestRadius_CD;
                tempPointsAB{idxA} = pointsAB;
                tempPointsCD{idxA} = pointsCD;
            end
        end

        % 保存局部最佳体积值
        tempTotalVolume(idxA) = localBestVolume;
    end
    
    % 在所有局部结果中找到最佳体积及其对应的参数
    [bestTotalVolume, idxBest] = min(tempTotalVolume);
    bestA = tempA(idxBest,:);
    bestB = tempB(idxBest,:);
    bestC = tempC(idxBest,:);
    bestD = tempD(idxBest,:);
    bestRadiusAB = tempRadiusAB(idxBest);
    bestRadiusCD = tempRadiusCD(idxBest);
    bestpointsAB = tempPointsAB{idxBest};
    bestpointsCD = tempPointsCD{idxBest};
end

function volume = computeCylinderVolume(A, B, radius)
    % 计算圆柱体的体积
    height = norm(A - B);
    if height < 30% 30
        height = 30;% 30
    end
    volume = pi * (radius^2) * height;
end
