function [center, radius] = enclosingBall(points)
    % 输入: 
    % points - 一个 Nx3 的矩阵, 表示 N 个三维的点
    %
    % 输出: 
    % center - 1x3 矩阵, 表示球心的坐标
    % radius - 标量, 表示球的半径
    
    % 计算质心
    center = mean(points, 1);

    % 计算到球心的最大距离作为半径
    distances = sqrt(sum(bsxfun(@minus, points, center).^2, 2));
    radius = max(distances);
end
