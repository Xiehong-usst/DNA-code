close all;
clear;
addpath(fullfile(pwd, 'utils'));
filename = 'Fig4B_tsa2023area2.tif';
Step1_readfile_tif_hu;
Step2_local_density;