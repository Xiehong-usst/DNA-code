function points = generate_sphere_points(center, radius, num_points)
    % 解包球心坐标
    x0 = center(1);
    y0 = center(2);
    z0 = center(3);
    
    % 初始化点数组
    points = zeros(num_points, 3);
    
    for i = 1:num_points
        % 使用球面坐标随机生成点
        phi = 2 * pi * rand(); % 方位角
        theta = acos(2 * rand() - 1); % 极角
        
        % 转换为笛卡尔坐标系
        x = radius * sin(theta) * cos(phi);
        y = radius * sin(theta) * sin(phi);
        z = radius * cos(theta);
        
        % 转换到球心
        points(i, :) = [x + x0, y + y0, z + z0];
    end
end


