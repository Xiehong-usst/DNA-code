function bestR = cylinder_fitR(points, A, B)
    % 输入:
    % points: 点的坐标，每一行是一个3D点，例如 points = [x1 y1 z1; x2 y2 z2; ...]
    % A, B: 圆柱体轴线的两个端点
    % R: 圆柱体的半径
    % 输出:
    % distances: 一个列向量，包含每个点到圆柱体的距离

    % 初始化返回向量
    n = size(points, 1);

    % 计算向量AB
    AB = B - A;
    AB_length = norm(AB);
    AB_unit = AB / AB_length;  % AB的单位向量

    bestR = 0;
    for i = 1:n
        P = points(i, :);  % 当前点
        AP = P - A;  % 向量AP

        % 计算点P在AB上的投影长度
        proj_length = dot(AP, AB_unit);
        % 计算投影点Q
        Q = A + proj_length * AB_unit;
        PQ = P - Q;
        PQ_length = norm(PQ);  % PQ的长度
        bestR = bestR + PQ_length;
        
    end
    bestR = bestR/n;
end
