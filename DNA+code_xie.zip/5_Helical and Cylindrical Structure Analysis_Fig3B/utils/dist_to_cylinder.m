function distances = dist_to_cylinder(points, A, B, R)
    % 输入:
    % points: 点的坐标，每一行是一个3D点，例如 points = [x1 y1 z1; x2 y2 z2; ...]
    % A, B: 圆柱体轴线的两个端点
    % R: 圆柱体的半径
    % 输出:
    % distances: 一个列向量，包含每个点到圆柱体的距离

    % 初始化返回向量
    n = size(points, 1);
    distances = zeros(n, 1);

    % 计算向量AB
    AB = B - A;
    AB_length = norm(AB);
    AB_unit = AB / AB_length;  % AB的单位向量

    for i = 1:n
        P = points(i, :);  % 当前点
        AP = P - A;  % 向量AP

        % 计算点P在AB上的投影长度
        proj_length = dot(AP, AB_unit);
        % 计算投影点Q
        Q = A + proj_length * AB_unit;
        PQ = P - Q;
        PQ_length = norm(PQ);  % PQ的长度

        % 判断垂足Q是否在线段AB上
        if proj_length >= 0 && proj_length <= AB_length
            distances(i) = abs(PQ_length - R);
        else
            dist_diff = abs(PQ_length - R);
            QA = norm(Q - A);
            QB = norm(Q - B);
            if QA < QB
                distances(i) = sqrt(QA^2 + dist_diff^2);
            else
                distances(i) = sqrt(QB^2 + dist_diff^2);
            end
        end
    end
end
