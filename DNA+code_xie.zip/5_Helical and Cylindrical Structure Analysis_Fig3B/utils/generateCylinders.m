function [inside_pointsA, inside_pointsB] = generateCylinders(A, B, R, cutn)
    
    % 计算AB向量和距离d
    AB = B - A;
    d = norm(AB);

    % 计算圆T的半径
    RT = R/2;

    % 找到垂直于AB的两个单位向量，这些向量将位于面q上
    if all(AB == 0)
        error('点A和点B不能相同');
    end
    v1 = null(AB(:)'); % 这将返回一个与AB垂直的单位向量集合

    % 选取两个互相垂直的向量作为直径的方向
    EF = v1(:,1);
    GH = v1(:,2);

    % 在直径上等分出10个点
    divisions = linspace(-RT, RT, cutn+2);
    
    % 计算EF和GH上的点
    pointsEF = zeros(cutn, 3);
    pointsGH = zeros(cutn, 3);
    for i = 2:length(divisions)-1
        pointsEF(i-1, :) = EF' * divisions(i);
        pointsGH(i-1, :) = GH' * divisions(i);
    end

    % 初始化存放结果的数组
    inside_pointsA = [];
    inside_pointsB = [];

    % 检查所有组合的点
    for i = 1:size(pointsEF, 1)
        for j = 1:size(pointsGH, 1)
            % 计算新的点
            P = A + pointsEF(i,:) + pointsGH(j,:);
            
            % 检查点P是否在圆T内部
            if norm(P - A) <= RT
                inside_pointsA = [inside_pointsA; P]; % 如果点在圆内部，加入到结果数组中
                inside_pointsB = [inside_pointsB; P-A+B]; % 如果点在圆内部，加入到结果数组中
            end
        end
    end
end
