function [A, B] = computeAB(u, point, tangentVector)
    % 计算切线向量的单位向量
    unitVector = tangentVector / norm(tangentVector);
    
    % 计算A和B的坐标
    A = point - u * unitVector;
    B = point + u * unitVector;
end
