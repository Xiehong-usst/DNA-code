function [minPoint, maxPoint] = newAB_by_points(points, A, B)
    % points 是一个Nx3的矩阵，每行代表一个点的坐标 (x, y, z)
    % A 和 B 是1x3的向量，代表点A和点B的坐标

    AB = B - A; % 计算向量AB
    AB_normalized = AB / norm(AB); % 计算单位向量AB
    
    % 初始化最小值和最大值
    min_q = inf;
    max_q = -inf;
    
    % 遍历所有点，计算投影
    for i = 1:size(points, 1)
        P = points(i, :); % 当前点P
        AP = P - A; % 向量AP
        q = dot(AP, AB_normalized); % 计算内积
        
        % 更新最小值和最大值
        if q < min_q
            min_q = q;
            minPoint = A + AB_normalized * q; % 计算最小值对应的点
        end
        if q > max_q
            max_q = q;
            maxPoint = A + AB_normalized * q; % 计算最大值对应的点
        end
    end
end
