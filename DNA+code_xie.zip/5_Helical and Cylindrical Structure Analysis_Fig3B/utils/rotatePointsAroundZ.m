function rotatedPoints = rotatePointsAroundZ(points, angle)
    % points 是一个 Nx3 矩阵，其中每行代表一个点 (x, y, z)
    % angle 是绕Z轴旋转的角度，以弧度为单位

    % 创建绕Z轴旋转的旋转矩阵
    Rz = [cos(angle) -sin(angle) 0;
          sin(angle)  cos(angle) 0;
          0           0          1];
    
    % 将旋转矩阵应用于所有点
    rotatedPoints = points * Rz';
end
