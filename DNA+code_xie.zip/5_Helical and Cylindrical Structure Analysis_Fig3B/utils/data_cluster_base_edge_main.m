clc;
clear;
close all;
% 获取所有以'3d'开头的.mat文件
file_list = dir('./dataset/live/*.fig');


% 对每个文件进行处理
all_D = [];
for idx = 1:length(file_list)
    file_name = file_list(idx).name;
    loadDataAndProcess(file_name);
end