% 加载数据
load('D:\LKY\DNA-matlab code\DNA-matlab code_240827\Chromatin Length and Diameter Measurement\data\20250722-data-lky\saved_variables\3d_cluster_area14_d_stats.mat');

% 遍历每个圆柱体
for i = 1:length(newCylinders)
    cylinder = newCylinders{i};
    
    % 提取圆柱体参数
    bestA = cylinder.bestA;
    bestB = cylinder.bestB;
    bestRadius = cylinder.bestRadius;
    dataPoints = cylinder.dataPoints;
    
    % 计算直径和长度
    cylinderDiameter = 2 * bestRadius;            % 直径 = 2倍半径
    cylinderLength = norm(bestA - bestB);          % 长度 = 两端点间欧氏距离
    
    % 创建新图形窗口
    figure('NumberTitle', 'off', 'Name', sprintf('Cylinder %d', i));
    
    % 随机生成颜色（与原函数保持一致）
    color1 = rand(1,3)*0.9;
    
    % 绘制当前圆柱体
    plot_cylinder_with_points(bestA, bestB, bestRadius, dataPoints, color1);
    new_data1 = cylinder.dataPoints;
    scatter3(new_data1(:,1), new_data1(:,2), new_data1(:,3), 'k', 'filled');
    % 设置标题和标签
    title(sprintf('Diameter: %.2f nm | Length: %.2f nm', cylinderDiameter, cylinderLength));
    xlabel('X (nm)'); ylabel('Y (nm)'); zlabel('Z (nm)');
    axis equal;  % 保持坐标轴比例一致
    grid on;
    
    % 添加旋转控制（可选）
    rotate3d on;
end