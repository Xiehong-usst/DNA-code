function plotAllCylinders(cylinders)
    % 遍历所有的圆柱体
    for i = 1:length(cylinders)
        cylinder = cylinders{i};

        bestA = cylinder.bestA;
        bestB = cylinder.bestB;
        bestRadius = cylinder.bestRadius;
        dataPoints = cylinder.dataPoints;
        color1 = rand(1,3)*0.9; % 随机生成颜
        plot_cylinder_with_points(bestA, bestB, bestRadius, dataPoints, color1);

        % % 计算数据点的质心
        % centroid = mean(dataPoints, 1);
        % 
        % % 在当前图形中绘制编号
        % text(centroid(1), centroid(2), centroid(3), num2str(i), ...
        %     'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k', ...
        %     'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
        
    end 
end
