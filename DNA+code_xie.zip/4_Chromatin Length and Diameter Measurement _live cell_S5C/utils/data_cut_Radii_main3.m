clear;
close all;

% 获取所有以'3d'开头的.mat文件
file_list = dir('*.mat');
cover_weight = 0.98;

for idx = 1:length(file_list)
    file_name = file_list(idx).name;
    data1 = loadDataAndProcess(file_name);
    k = loadDataAndProcess2(file_name);
    
    file_name2 = ['.\saved_variables\3d_cluster_area' num2str(k) '_loc_multi_fit_single.mat'];
    load(file_name2);
    % 对所有圆柱体进行进一步处理，以得到与其相对应的数据点
    
    tic;
    %原始值20
    cut_set = 40;
    
    new_data1 = [];
    
    newCylinders = [];
    nn1 = 0;
    for k = 1:numel(allCylinders)
        A1 = allCylinders{k}.bestA;
        B1 = allCylinders{k}.bestB;
        R1 = allCylinders{k}.bestRadius;
        inside = is_inside_cylinder(data1, A1, B1, R1+2);
        n1 = find(inside == 1);
        new_data1 = [new_data1; data1(n1,:)];
    
        new_datak = data1(n1,:);
        d1 = norm(B1 - A1);
        % nd = floor(d1/cut_set);
        nd = 1;
        cutd = d1/nd;
        groupedPoints = [];
        Alist = [];
        Blist = [];
        if nd > 1
            AB = B1 - A1;
            AB_length = norm(AB);
            AB_unit = AB / AB_length;
            for r = 1:nd
                Alist{r} = A1 + (r - 1)*cutd*AB_unit;
                Blist{r} = A1 + r*cutd*AB_unit;
            end
            cleaned_data = removeDuplicatePoints(new_datak);
            groupedPoints = groupPointsByDistance(cleaned_data, A1, B1, cutd);
        else
            Alist{1} = A1;
            Blist{1} = B1;
            cleaned_data = removeDuplicatePoints(new_datak);
            groupedPoints{1} = cleaned_data;
        end
        for r = 1:numel(Alist)
            [Rbest, newA1, newB1] = calculate95PercentileDistance(groupedPoints{r}, Alist{r}, Blist{r}, cover_weight);
            cylinder1 = [];
            cylinder1.bestA = newA1;
            cylinder1.bestB = newB1;
            cylinder1.bestRadius = Rbest;
            cylinder1.dataPoints = groupedPoints{r};
            nn1 = nn1 + 1;
            newCylinders{nn1} = cylinder1;
        end
    end
    toc;
    
    % 创建3D散点图以可视化所有的圆柱体和相关的数据点
    fig = figure;
    scatter3(data1(:,1), data1(:,2), data1(:,3), 'k', 'filled');
    hold on;
    plotAllCylinders(newCylinders);
    lengths = getCylinderLengths(newCylinders);
    radii = getCylinderRadii(newCylinders);
    % scatter3(new_data1(:,1), new_data1(:,2), new_data1(:,3), 'k', 'filled');
    set(gcf,'color','white'); %窗口背景白
 
     colordef white; %2D/
    
    save_name_gradient = fullfile('saved_variables', [file_name(1:end-4) '_d_stats.mat']);
    save(save_name_gradient, 'lengths','radii','newCylinders');
    fig_name = fullfile('saved_figures', [file_name(1:end-4) '_cut_main3.fig']);
    savefig(fig_name);

    %% 添加局部放大图功能
    fig2 = copyobj(fig, 0); % 创建主图的完整副本
    set(fig2, 'Name', 'Local Cylinder Views');
    
    % 设置主图显示范围
    allPoints = [];
    for i = 1:numel(newCylinders)
        allPoints = [allPoints; newCylinders{i}.dataPoints];
    end
    margin = max(range(allPoints)) * 0.2; % 20%边距
    xlims = [min(allPoints(:,1))-margin, max(allPoints(:,1))+margin];
    ylims = [min(allPoints(:,2))-margin, max(allPoints(:,2))+margin];
    zlims = [min(allPoints(:,3))-margin, max(allPoints(:,3))+margin];
    
    % 创建网格布局
    tiledlayout_handle = tiledlayout(fig2, 'flow', 'TileSpacing', 'tight', 'Padding', 'tight');
    title(tiledlayout_handle, [file_name(1:end-4) ' - Cylinder Local Views'], 'FontSize', 12);
    
    for cylIdx = 1:numel(newCylinders)
        cyl = newCylinders{cylIdx};
        
        % 创建新坐标系
        ax = nexttile(tiledlayout_handle);
        
        % 计算圆柱区域范围
        cylPoints = cyl.dataPoints;
        cylMargin = max(range(cylPoints)) * 1; % 50%边距
        
        % 绘制主图所有点云（灰色半透明）
        scatter3(ax, data1(:,1), data1(:,2), data1(:,3), 10, [0.7 0.7 0.7], 'filled', 'MarkerEdgeAlpha', 0.1, 'MarkerFaceAlpha', 0.1);
        hold(ax, 'on');
        
        % 高亮当前圆柱体点云（红色）
        scatter3(ax, cylPoints(:,1), cylPoints(:,2), cylPoints(:,3), 20, 'r', 'filled');
        
        % 绘制当前圆柱体
        [cylX, cylY, cylZ] = cylinderMesh(cyl.bestA, cyl.bestB, cyl.bestRadius, 20);
        surf(ax, cylX, cylY, cylZ, 'FaceColor', 'b', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
        
        % 绘制其他圆柱体（半透明青色）
        for otherIdx = 1:numel(newCylinders)
            if otherIdx == cylIdx, continue; end
            otherCyl = newCylinders{otherIdx};
            [otherX, otherY, otherZ] = cylinderMesh(otherCyl.bestA, otherCyl.bestB, otherCyl.bestRadius, 10);
            surf(ax, otherX, otherY, otherZ, 'FaceColor', 'c', 'FaceAlpha', 0.1, 'EdgeColor', 'none');
        end
        
        % 设置当前视角和范围
        midPoint = (cyl.bestA + cyl.bestB)/2;
        axis(ax, 'equal');
        xlim(ax, [midPoint(1)-cylMargin, midPoint(1)+cylMargin]);
        ylim(ax, [midPoint(2)-cylMargin, midPoint(2)+cylMargin]);
        zlim(ax, [midPoint(3)-cylMargin, midPoint(3)+cylMargin]);
        
        % 添加标题和标注
        length = norm(cyl.bestB - cyl.bestA);
        title(ax, sprintf('Cyl %d: L=%.1f, R=%.1f', cylIdx, length, cyl.bestRadius), 'FontSize', 10);
        
        % 设置美观视角
        view(ax, -30, 30);  % 3D视角
        grid(ax, 'on');
        box(ax, 'on');
    end
    
    % 保存局部放大图
    local_fig_name = fullfile('saved_figures', [file_name(1:end-4) '_cut_local_views.fig']);
    savefig(fig2, local_fig_name);
    % close(fig2); % 关闭副本
end

%%
% 统计唯一坐标及其出现次数
[unique_coords, ~, ic] = unique(data1, 'rows', 'stable'); % 'stable'保持原始顺序
counts = accumarray(ic, 1); % 每个唯一坐标的出现次数

% 合并唯一坐标和计数（去重后的数据）
area1_loc_with_counts = [unique_coords, counts]; % N_unique × 4 矩阵
pointCloud = area1_loc_with_counts(:, 1:3) * 3;  % 放大3倍
R = 10; % 定义邻域半径(单位：nm)，根据实际情况调整

%% 提取坐标和出现次数
points = area1_loc_with_counts(:,1:3); % 前三列为坐标
counts = area1_loc_with_counts(:,4);    % 第四列为出现次数

%% 计算每个点的密度（考虑出现次数的权重）
num_points = size(points,1);
normalized_density = zeros(num_points,1);

for i = 1:num_points
    % 计算当前点到所有点的距离
    distances = sqrt(sum((points - points(i,:)).^2, 2));
  
    % 找出在半径R内的点（包括自身）
    mask = (distances <= R/3);
  
    % 加权统计总出现次数（密度）
    total_count = sum(counts(mask));
  
    % 标准化密度 = 总次数 / 球体体积
    normalized_density(i) = total_count / (4/3 * pi * R^3);
end

%% 可视化密度分布
figure;
scatter3(pointCloud(:,1), pointCloud(:,2), pointCloud(:,3), 5, normalized_density, 'filled');
colormap jet; colorbar; axis equal;
xlabel('X (nm)'); ylabel('Y (nm)'); zlabel('Z (nm)');
title(['密度分布 (R = ', num2str(R), ' nm)']);
set(gcf, 'color', 'white');
axis equal;
colordef white;

%% 保存结果
save('.\saved_variables\area1_density_results.mat', 'points', 'counts', 'normalized_density', 'R');

%% 完全重写 cylinderMesh 函数（简洁实用版）
function [X, Y, Z] = cylinderMesh(A, B, R, n)
    % 计算圆柱方向向量
    direction = B - A;
    height = norm(direction);
    if height < eps  % 避免零向量
        direction = [0 0 1];
        height = 1;
    end
    z_unit = direction / height;
    
    % 生成基础圆柱
    [cx, cy, cz] = cylinder(R, n);
    cz = cz * height;  % 调整高度
    
    % 计算变换到目标方向的点
    X = zeros(size(cx));
    Y = zeros(size(cy));
    Z = zeros(size(cz));
    
    for i = 1:size(cx, 1)
        for j = 1:size(cx, 2)
            % 基础点 (在局部坐标系)
            local_point = [cx(i,j), cy(i,j), cz(i,j)];
            
            % 直接计算变换位置
            % 使用向量投影方法，避免旋转矩阵
            % 简单可靠的变换方法
            up = [0 0 1];
            axis = cross(up, z_unit);
            if norm(axis) < eps
                axis = [1 0 0];
            end
            axis = axis / norm(axis);
            angle = acos(dot(up, z_unit));
            
            % Rodrigues 旋转公式（直接计算）
            rotated_point = local_point*cos(angle) + ...
                           cross(axis, local_point)*sin(angle) + ...
                           axis*dot(axis, local_point)*(1-cos(angle));
            
            final_point = rotated_point + A;
            
            X(i,j) = final_point(1);
            Y(i,j) = final_point(2);
            Z(i,j) = final_point(3);
        end
    end
end

function cleaned_data = removeDuplicatePoints(new_datak)
    % 参数: new_datak - n×3 矩阵，包含浮点误差的坐标点
    % 返回值: cleaned_data - 去除重合点后的矩阵
    
    % 设置容差阈值 (根据实际精度需求可调整)
    tol = 1e-5;
    
    % 使用四舍五入处理浮点误差
    rounded_points = round(new_datak * (1/tol)) * tol;
    
    % 找到唯一行索引 (保留首次出现顺序)
    [~, unique_indices] = unique(rounded_points, 'rows', 'stable');
    
    % 按原始顺序提取唯一点
    cleaned_data = new_datak(sort(unique_indices), :);
end