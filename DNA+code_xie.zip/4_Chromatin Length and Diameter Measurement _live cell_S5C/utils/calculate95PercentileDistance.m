function [R, A1_updated, B1_updated] = calculate95PercentileDistance(P, A, B, cover_weight)
arguments
    P 
    A 
    B 
    cover_weight = 0.95
end
% 初始化s为零向量
s = zeros(1, size(A, 2));

% 计算向量AB和它的单位向量
AB = B - A;
AB_length = norm(AB);
AB_unit = AB / AB_length;

% 计算所有垂足Q并累积QP向量
Q_all = zeros(size(P));
for i = 1:size(P, 1)
    AP = P(i, :) - A;
    proj_length = dot(AP, AB_unit);
    Q = A + proj_length * AB_unit;
    Q_all(i, :) = Q;
    s = s + (Q - P(i, :));
end

% 计算s的均值
s = s / size(P, 1);

% 得到新的A1和B1
A1 = A - s;
B1 = B - s;

% 计算新的向量A1B1和它的单位向量
A1B1 = B1 - A1;
A1B1_length = norm(A1B1);
A1B1_unit = A1B1 / A1B1_length;

% 计算所有P到线段A1B1的距离和投影参数
distances = zeros(size(P, 1), 1);
projection_params = zeros(size(P, 1), 1);  % 存储投影点参数

for i = 1:size(P, 1)
    A1P = P(i, :) - A1;
    proj_length = dot(A1P, A1B1_unit);
    proj_point = A1 + proj_length * A1B1_unit;

    % 确保投影点在A1B1上
    if proj_length < 0
        proj_point = A1;
        projection_params(i) = 0;  % 参数化位置 (A1端)
    elseif proj_length > A1B1_length
        proj_point = B1;
        projection_params(i) = 1;  % 参数化位置 (B1端)
    else
        projection_params(i) = proj_length / A1B1_length;  % 中间位置
    end

    distances(i) = norm(P(i, :) - proj_point);
end

% 返回所有距离的95%分位数
R = prctile(distances, cover_weight*100);

%% 新增功能：基于垂足更新线段端点 %%
% 按投影参数排序
[~, sorted_idx] = sort(projection_params);
sorted_params = projection_params(sorted_idx);

% 计算需要保留的垂足范围
discard_ratio = (1 - cover_weight) / 2;
keep_start = floor(size(P, 1) * discard_ratio) + 1;
keep_end = size(P, 1) - floor(size(P, 1) * discard_ratio);

% 获取保留的垂足参数
min_param = sorted_params(keep_start);
max_param = sorted_params(keep_end);

% 计算新端点位置
A1_updated = A1 + min_param * A1B1;
B1_updated = A1 + max_param * A1B1;
end