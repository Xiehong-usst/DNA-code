clear; close all; clc;

%% 加载数据
load('3d_cluster_area1_loc.mat'); % 加载包含坐标和出现次数的数据
pointCloud = area1_loc_with_counts(:, 1:3) * 3;  % 放大3倍
R = 8; % 定义邻域半径(单位：nm)，根据实际情况调整

%% 提取坐标和出现次数
points = area1_loc_with_counts(:,1:3); % 前三列为坐标
counts = area1_loc_with_counts(:,4);    % 第四列为出现次数

%% 计算每个点的密度（考虑出现次数的权重）
num_points = size(points,1);
normalized_density = zeros(num_points,1);

for i = 1:num_points
    % 计算当前点到所有点的距离
    distances = sqrt(sum((points - points(i,:)).^2, 2));
  
    % 找出在半径R内的点（包括自身）
    mask = (distances <= R/3);
  
    % 加权统计总出现次数（密度）
    total_count = sum(counts(mask));
  
    % 标准化密度 = 总次数 / 球体体积
    normalized_density(i) = total_count / (4/3 * pi * R^3);
end

%% 可视化密度分布
figure;
scatter3(pointCloud(:,1), pointCloud(:,2), pointCloud(:,3), 5, normalized_density, 'filled');
colormap jet; colorbar; axis equal;
xlabel('X (nm)'); ylabel('Y (nm)'); zlabel('Z (nm)');
title(['密度分布 (R = ', num2str(R), ' nm)']);
set(gcf, 'color', 'white');
axis equal;
colordef white;

%% 保存结果
save('area1_density_results.mat', 'points', 'counts', 'normalized_density', 'R');