% 加载数据（确保MAT文件中变量名正确）
load('area2023071601_loc_time.mat', 'area2023071601_loc');

% 提取前三列坐标
coords = area2023071601_loc(:, 1:3);

% 统计唯一坐标及其出现次数
[unique_coords, ~, ic] = unique(coords, 'rows', 'stable'); % 'stable'保持原始顺序
counts = accumarray(ic, 1); % 每个唯一坐标的出现次数

% 合并唯一坐标和计数（去重后的数据）
area1_loc_with_counts = [unique_coords, counts]; % N_unique × 4 矩阵

% 保存结果
save('area1_loc_with_counts.mat', 'area1_loc_with_counts'); 
disp('处理完成：去重后的数据，第四列为坐标出现次数');